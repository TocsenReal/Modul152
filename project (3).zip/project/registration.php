<?php require_once "controller/PageBuilder.php"; ?>

<?php PageBuilder::start("Manga","Anime", "User"); ?>

<?php require_once "controller/registration.php"; ?>
<?php require_once "view/registration.php"; ?>

<?php PageBuilder::end(); ?>