
<?php require_once "controller/PageBuilder.php"; ?>
<?php require_once "controller/logout.php"; ?>
<?php PageBuilder::start("Manga","Anime", "User"); ?>

<?php require_once "controller/login.php"; ?>
<?php require_once "view/login.php"; ?>

<?php PageBuilder::end(); ?>