
<?php require "controller\PageBuilder.php"; 
PageBuilder::start();
?>

        <p class="Datenschutztext">Datenschutz:<br>so die daten die sie hier eingeben werden geschpeichert und nicht weiter geschickt oder kenutzt sie konnen sich sicher sein <br>
    es wird auch ein session cookie gespeichert das wenn sie die seite verlassen und zurück kommen immer noch ihre daten gespeichert sind und sie vortfahren können ohne Relogin.</p>

