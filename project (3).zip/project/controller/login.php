<?php

	require_once "model/test.php";

	//Do nothing if the submit button was not pressed.
	if (!isset($_POST["anmelden"])) {
		return;
	}
	
	//Check if the credentials are provided.
	if (empty($_POST["email"]) || empty($_POST["password"])) {
		$login_error = "Du musst deine E-Mail-Adresse und dein Passwort angeben.";
		return;
	}

	$email = $_POST["email"];
	$password = $_POST["password"];

	//Get the stored password hash for the user with the given email address.
	$testv = $database->query("SELECT user_id, password FROM user WHERE email = ? LIMIT 1", array($email), array("s"));
	
	$user = $testv[0];
	
	//Return an error message when no user with this email address was found or the password is invalid.
	if (!$user || !password_verify($email . $password, $user["password"])) {
		$login_error = "Diese Anmeldedaten sind falsch.";
		return;
	}

	//Start a session with a new ID and delete the old session data (true flag). This is to prevent multiple users having the same session ID.
	session_start();
	session_regenerate_id(true);

	//Write the session into the database.
	$database->query("UPDATE user SET session = ? WHERE user_id = ? LIMIT 1", array(session_id(), $user["user_id"]), array("s", "s"));
	
	//Set the session expiration time.
	$_SESSION["expiration_time"] = time() + 0.1 * 60; //Current time plus 30 minutes times 60 seconds.

	//When we arrive here, the login must have been successful. So we shall redirect the user to the profile page.
	header("Location: user.php");¨
	
?>