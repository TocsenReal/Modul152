
<?php
$ua = htmlentities($_SERVER['HTTP_USER_AGENT'], ENT_QUOTES, 'UTF-8');
if (preg_match('~MSIE|Internet Explorer~i', $ua) || (strpos($ua, 'Trident/7.0') !== false && strpos($ua, 'rv:11.0') !== false)) {
	
	echo "IE wird nicht unterstützt "; 
	
	echo "<a href='https://www.opera.com/de/gx'>Opera GX</a>";
	die;
	
}
	ini_set('display_errors', '1');
	ini_set('display_startup_errors', '1');
	error_reporting(E_ALL);

	class PageBuilder {

		public static function start($PageTitle = "", $PageKey = "") {
			echo "<!DOCTYPE html>
<html>
	<head>
		<meta charset=\"utf-8\">
		<title>" . $PageTitle . "</title>
		<link rel='icon' type='image/view/pic/scotty.webp' href='view/pic/scotty.webp'>
		<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
		<link rel=\"stylesheet\" type=\"text/css\" href=\"view/style/StyleCss.css\">

	</head>
	<body>
	<div class='navbar'>
	<a href=\"manga.php\">Home</a>
	<a href=\"user.php\" >User</a>
  <div class='dropdown'>
    <button class='dropbtn'>Valorant agent</a>
      <i class='fa fa-caret-down'></i>
    </button>
    <div class='dropdown-content'>
	<a href=\"anime.php\" >Agent anschauen</a>
	<a href=\"Hinzufügenanimemanga.php\">Hinzufügen</a>
    
    </div>
  </div> 
  
</div>

";
		}

		public static function end() {
			echo "
			</div>
			<div class=\"vertical-centerer\"></div>
			<div class=\"footer\">
				<span>© " . date("Y") . " Tocsen Real</span>
				<span>・</span>
				<a href=\"Datenschutz.php\" class='Datenschutz' >Datenschutz</a>
			</div>
		</div>
	</body>
</html>";
		}
	}
?>