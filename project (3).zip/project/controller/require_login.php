<?php
	/*
		Check whether a valid session is given and redirect the user to the login page if not so.
	*/

	function redirect_to_login_page() {
		session_unset();
		session_destroy();
		header("Location: login.php");
		die();
	}

	//Open the database connection.
	require_once "model/test.php";

	//Start or continue the session.
	session_start();
	

	if (!isset($_SESSION["expiration_time"]) || $_SESSION["expiration_time"] <= time()) {
		//If no expiration time is set in the session data or the expiration time has already passed, destroy the session and redirect to the login page.
		redirect_to_login_page();
	}

	//Check for a user with the current session in the database.
	
	
	$testv = $database->query("SELECT * FROM user WHERE session = ? LIMIT 1", array(session_id()), array("s"));
	
	$user = $testv[0];
	
	if (!$user) {
		//If no user was found with this session, redirect to the login page.
		redirect_to_login_page();
	}

	//If the session is valid, update the expiration time.
	$_SESSION["expiration_time"] = time() + 30 * 60; //Current time plus 30 minutes times 60 seconds.
?>