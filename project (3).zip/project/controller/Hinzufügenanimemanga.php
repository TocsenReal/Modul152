<?php

require_once "model/test.php";



if (!isset($_POST["submit"])){
    return;
}

$uploadTo = "view/pic/"; 
$allowedImageType = array('jpg','png','jpeg');
$countFile = 0;
$totalFiles = glob($uploadTo . "*");


if ($totalFiles)
{
    $countFile = count($totalFiles);
}

$Name=$_POST["titel"];

$CC=$_POST["CC"];

$realName = $_FILES["image"]["name"];



$imageName = $_FILES["image"]["name"] = microtime(true) . ".jpg";




$tempPath=$_FILES["image"]["tmp_name"];
$basename =  basename($imageName);

$originalPath = $uploadTo.$basename; 
$imageType = pathinfo($originalPath, PATHINFO_EXTENSION); 

if(!empty($imageName)){ 

    if(in_array($imageType, $allowedImageType))
    { 
        
        if(move_uploaded_file($tempPath,$originalPath)){ 
            $createEmp = $database->query("INSERT INTO anime_manga(name, Picname ,CC ) VALUES(?, ?,?)", array($Name,$basename,$CC), array("s","s","s"));
        }else{ 
            echo 'image Not uploaded ! try again';
            return;
        } 
    }
    else
    {
        echo $imageType." image type not allowed";
        return;
    }
   }
   else{
    echo "Please Select a image";
    return;
} 
?>