
<?php require_once "controller/Pagebuilder.php"; 
 

        session_start();
        session_unset();
		session_destroy();
?>

