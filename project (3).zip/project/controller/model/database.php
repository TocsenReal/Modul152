<?php

class database{
    private $db;
    function connect(){
        if($this->db ==Null){
            $this->db =new databaseconnection("localhost","root","","userdatabank");
            $this->db->connect();
        }
    }
 
    function getAnime($id = null){
        $this->connect();
        
        if ($id) {
            return $this->db->query("SELECT * FROM anime_manga WHERE id = ? ORDER by `Like` Desc", array($id), array("i"));
        }
        else {
            return $this->db->query("SELECT * FROM anime_manga ORDER by `Like` Desc");
        }
    }
    function Likeid($id)
    {$this->connect();
        $resolt = $this->db->query("SELECT `Like` FROM anime_manga where id=$id");
        $Like = $resolt[0]["Like"] + 1;
        
        $resolt = $this->db->query("Update anime_manga Set `Like`=$Like where id=$id");
     
    }

}
