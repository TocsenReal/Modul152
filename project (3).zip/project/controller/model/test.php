<?php
require "databaseconnection.php";
$database = new databaseconnection("localhost","root","","userdatabank");

//foreach($database->query("select * from anime_manga where IsManga = 1") as $i){
//echo $i["Name"] ."<br>";
//}
//echo $database->query("select * from manga")[0]["Name"];