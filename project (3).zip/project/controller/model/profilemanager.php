<?php
	class ProfileManager {
		private static $user;

		/**
		 * Fetches the user from the current session.
		 */
		public static function initialize() {
			global $database;
			
            $getuser = $database->query("SELECT * FROM user WHERE session = ? LIMIT 1", array(session_id()), array("s"));
           
            self::$user = $getuser[0];
			//Redirect to the login page if no user was found.
			if (!self::$user) {
				header("Location: login.php");
			}
		}

		/**
		 * Returns the email address of the currently logged in user.
		 */
		public static function getusername() {
			return [self::$user["username"], self::$user["email"]];
			
			
		}
	}
?>