<?php
	require_once "model/test.php";
	require_once "model/profilemanager.php";


	require_once "controller/model/databaseconnection.php";
	require_once "controller/model/database.php"; 
   
 
   
	ProfileManager::initialize();
?>
