<?php
 require_once "controller/model/databaseconnection.php";
 require_once "controller/model/database.php"; 
$cool = new database;
$cool->getAnime();