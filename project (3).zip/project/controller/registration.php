<?php
	require_once "model/test.php";

	//Do not do anything if the submit button was not pressed.
	if (!isset($_POST["submit"])) {
		return;
	}

	//Display an error message when not all fields are set.
	if (!isset($_POST["email"]) || !isset($_POST["password"]) || empty($_POST["email"]) || empty($_POST["password"])) {
		$signup_error = "Du musst deine E-Mail-Adresse und ein Passwort eingeben.";
		return;
	}

	//Fetch the credentials.
	$email = $_POST["email"];
	$password = $_POST["password"];
    $username = $_POST["username"];
	//Limit the length of the email address.
	if (strlen($email) > 500) {
		$signup_error = "Die E-Mail-Adresse ist zu lang.";
		return;
	}

	//Limit the length of the password.
	if (strlen($password) > 500) {
		$signup_error = "Das Passwort ist zu lang.";
		return;
	}

	//Validate the email format.
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		$signup_error = "Die E-Mail-Adresse ist invalid.";
		return;
	}

	//Check if there is already a user with the given email address.
	$getUser = $database->query("SELECT user_id FROM user WHERE email = ?", array($email), array("s"));
	if ($getUser->num_rows > 0) {
		$signup_error = "Ein Benutzer mit dieser E-Mail-Adresse existiert bereits. Klicke <a href=\"login.php\">hier</a>, um zur Anmeldung zu gelangen.";
		return;
	}

	//If we arrived here, the credentials are valid, so we can start a session to obtain the session ID.
	//Start a session with a new ID and delete the old session data (true flag). This is to prevent multiple users having the same session ID.
	session_start();
	session_regenerate_id(true);

	//Create the user in the database.
    $createUser = $database->query("INSERT INTO user(email, password, username ,session) VALUES(?, ?, ?, ?)", array($email, password_hash($email . $password, PASSWORD_DEFAULT), $username , session_id()), array("s","s","s","s"));
    print_r($createUser);
   

	//If the creation was not successful, return an error message.
	if (!$createUser || ($createUser !== true && $createUser->affected_rows != 1)) {
		$signup_error = "Die Registration ist wegen eines Serverfehlers fehlgeschlagen. Bitte versuche es mit anderen Eingaben oder melde dieses Problem.";
		return;
	}

	//Set the session expiration time.
	$_SESSION["expiration_time"] = time() + 30 * 60; //Current time plus 30 minutes times 60 seconds.

	//When we arrive here, the creation of the account must have been successful. So we shall redirect the user to the profile page.
    header("Location: user.php");
?>
   