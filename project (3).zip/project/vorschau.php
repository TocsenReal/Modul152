<?php require_once "controller/require_login.php" ?>
<?php require_once "controller/PageBuilder.php"; ?>

<?php PageBuilder::start("Valorant Agent", "User", "hinzufügen"); ?>

<?php require_once "controller/vorschau.php"; ?>
<?php require_once "view/vorschau.php"; ?>

<?php PageBuilder::end(); ?>