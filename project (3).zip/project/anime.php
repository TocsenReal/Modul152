<?php require_once "controller/require_login.php" ?>
<?php require_once "controller/PageBuilder.php"; ?>

<?php PageBuilder::start("Valorant Agent", "User", "hinzufügen"); ?>

<?php require_once "controller/anime.php"; ?>
<?php require_once "view/anime.php"; ?>

<?php PageBuilder::end(); ?>