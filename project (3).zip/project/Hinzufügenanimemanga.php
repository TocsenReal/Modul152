<?php require_once "controller/require_login.php" ?>

<?php require_once "controller/PageBuilder.php"; ?>

<?php PageBuilder::start(""); ?>

<?php require_once "controller/Hinzufügenanimemanga.php"; ?>
<?php require_once "view/Hinzufügenanimemanga.php"; ?>

<?php PageBuilder::end(); ?>