<form method="POST" enctype="multipart/form-data">




<div class="boarderforinfohinzufügen">
<input type="text" name ="titel" id="titel" placeholder="titel" >

<br><input type="radio" name="CC" id="CC" value="CC0">CC0
<br><input type="radio" name="CC" id="CC" value="BY">BY
<br><input type="radio" name="CC" id="CC" value="BY-SA">BY-SA
<br><input type="radio" name="CC" id="CC" value="BY-NC">BY-NC
<br><input type="radio" name="CC" id="CC" value="BY-BC-SA">BY-BC-SA
<br><input type="radio" name="CC" id="CC" value="BY-ND">BY-ND
<br><input type="radio" name="CC" id="CC" value="BY-NC-ND">BY-NC-ND

<br><input  type="file"  name ="image" id="image" accept="image/jpg" onchange="preview_image(event)" >
 <div id="image-box"  ><img id="output_image" class="blank" alt=""  ></div>
 
 <p><input type="submit" class="button" name="submit"></p>
 </div>
 </form>
 <script type='text/javascript'>

function preview_image(event) 
{
 var reader = new FileReader();
 reader.onload = function()
 {
  var output = document.getElementById('output_image');
  output.src = reader.result;
 }
 reader.readAsDataURL(event.target.files[0]);
}
function imagePreview(fileInput) {
    if (fileInput.files && fileInput.files[0]) {
        var fileReader = new FileReader();
        fileReader.onload = function (event) {
            $('#preview').html('<img src="'+event.target.result+'>');
        };
        fileReader.readAsDataURL(fileInput.files[0]);
    }
}
$("#image").change(function () {
    imagePreview(this);
});
</script>
