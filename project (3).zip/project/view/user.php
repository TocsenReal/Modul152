
<div class="boarderforinfo"> 


<p><?php $resolt = ProfileManager::getusername();
echo "<h1> Hello  $resolt[0] </h1>




<button><a href='login.php' class='abmelden'>Abmelden</a></button>

</div>
";


?>