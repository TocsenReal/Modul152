<!Doctype html>
<html>
<head></head>

<Body>

    <div class="boarderforinfo">
        <h1>Lul</h1>

        <?php if (!empty($login_error)): ?>
	<p class="error-box"><?php echo $login_error; ?></p>
<?php endif; ?>

<form method="POST">
 

        <label for = "Email">Enter creators E-Mail</label>
        <input id="Email" type ="email" name="email" placeholder ="E-Mail" >
        <br>
        
        
        <label for = "PW">Enter creators Password</label>
        <input id="PW" type ="password" name="password" placeholder="Password" >
        
<br>
        <input  type="submit" name="anmelden" value="anmelden" class="button">
        <button><a href="registration.php" class="abmelden">Registration</a></button>
        <br>
        

        </form>
    </div>
</Body>

</html>