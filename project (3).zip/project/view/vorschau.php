<!DOCTYPE html>
<?php
$V = new database
?>
<html lang="en">

    
<head>
<title>Anime</title>
</head>
<body>
<div class="boarderforinfo">
   
<?php $saveid = $_GET['id']; ?>
      <?php foreach ($V->getAnime($saveid) as $M): ?>
       
        <h1><?= $M["Name"]?></h1>
        <picture><img src="view/pic/<?= $M["Picname"] ?>" alt=""style="width: 5rem;max-width: 50%;height: auto;vertical-align:  middle;border-style: none;"></picture>
      
  <?php break;?>    
  <?php endforeach; ?> 

</div>
</body>
</html>
<?php if($_SERVER['REQUEST_METHOD'] == 'POST')
{
$A = new database ; 
$A->Likeid($_POST["id"]);

}

?>