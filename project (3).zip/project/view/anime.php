<!DOCTYPE html>
<?php
$V = new database
?>
<html lang="en">

    
<head>
<title>Anime</title>
</head>
<body>
<div class="boarderforinfo">
    <h1>Agent</h1>
   
      <?php foreach($V->getAnime()as $M): ?>
       
        <table class="tdanm">
        <tr class="trclass">
    
    <td class="blank2"><?= $M["Name"]?></td>
    <td class="blank2"><?= $M["CC"]?></td>
    <td class="blank2"><a href="vorschau.php?id=<?php echo $M['id']?>" target="_blank">    <picture><img class="img" src="view/pic/<?= $M["Picname"] ?>" alt=""></picture></a></td>
     
    <td>
        <form method="POST">
              <input type="hidden" name="id" value="<?= $M["id"]?>">

              <input type="submit" name="Like" value="like" class="button">
        </form>

      </td>
  </tr>
  </div>
 <?php endforeach; ?> 
</table>
</div>
</body>
</html>
<?php if($_SERVER['REQUEST_METHOD'] == 'POST')
{
$A = new database ; 
$A->Likeid($_POST["id"]);

}

?>
