<!DOCTYPE html>
<?php
$V = new database
?>
<html lang="en">

    
<head>
<title>Manga</title>

</head>
<body>

<div class="boarderforinfo">
<picture>
  <img src="view/pic/scotty.webp"  alt="tocsen" style="width:50%;">
</picture>
    <h1>Where Legends are born</h1>
    <picture>
    <img src='view/pic/valo.webp' alt='tocsen' style='width:100%;'>
</picture>
      
</div>
</body>
</html>


