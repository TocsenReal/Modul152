<div class="boarderforinfo">
<h1>Neues Profil erstellen</h1>

<?php if (!empty($signup_error)): ?>
	<p class="error-box"><?php echo $signup_error; ?></p>
<?php endif; ?>
<form method="POST">
    <input type="text" name="username" required="true" maxlength="500" placeholder="Username" value="<?php echo (isset($_POST["username"]) ? $_POST["username"] : ""); ?>">
	<input type="email" name="email" required="true" maxlength="500" placeholder="E-Mail-Adresse" value="<?php echo (isset($_POST["email"]) ? $_POST["email"] : ""); ?>">
    <input type="password" name="password" required="true" maxlength="500" placeholder="Passwort">
	<br><input type="submit" name="submit" value="Registrieren" class="button default">
</form>
<p class="abmelden">Durch die Anmeldung wird ein Cookie gespeichert. Mehr Informationen unter <a href="Datenschutz.php" class="hyperlink">Datenschutz</a>.</p>

<p class="abmelden">Wenn du schon ein Konto hast, kannst du dich <br><br>
 <button><a href="login.php"class="abmelden">hier anmelden</a></button></p>
</div>