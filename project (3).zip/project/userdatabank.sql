-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2022 at 11:57 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userdatabank`
--

-- --------------------------------------------------------

--
-- Table structure for table `anime_manga`
--

CREATE TABLE `anime_manga` (
  `id` int(11) NOT NULL,
  `Name` text NOT NULL,
  `Picname` text NOT NULL,
  `Like` int(11) DEFAULT 0,
  `IsManga` int(1) NOT NULL DEFAULT 0,
  `Url` text NOT NULL,
  `CC` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `anime_manga`
--

INSERT INTO `anime_manga` (`id`, `Name`, `Picname`, `Like`, `IsManga`, `Url`, `CC`) VALUES
(48, 'astra', '1646992070.4234.jpg', 5, 0, '', 'CC0'),
(49, 'Viper', '1646992144.0811.jpg', 0, 0, '', 'CC0'),
(50, 'a', '1646995135.4449.jpg', 0, 0, '', 'BY-NC'),
(51, 'a', '1646995141.2232.jpg', 0, 0, '', 'BY-SA');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `email` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL,
  `username` text NOT NULL,
  `logincounter` int(11) NOT NULL,
  `session` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `email`, `password`, `username`, `logincounter`, `session`) VALUES
(2, 'bbb@gmail.com', '$2y$10$Pi3BbR2vXB4mPY/q/jIJgOoQLPz9xqZbcbmblgqdZsqtDixQdbU12', 'bbb', 0, '6h9nt9frbg6vao337rkul88qsn'),
(3, 'aaa@gmail.com', '$2y$10$VP1jW0GW477qS33B0oGYsO5hyfaGOzrmL3dp7AEJ4/uMoH1spUR1S', 'aaa', 0, 'jd94aelggc3tt1rhp9sjmnfaf7'),
(5, 'ddd@gmail.com', '$2y$10$Fe3nx9kYUVETxfX48w44lu5rbhYEC1clvqC/.p7mksLiMuRQaxQjW', 'ddd', 0, '6gq87f38a8lbqkkn2065hlg9hk'),
(6, 'eee@gmail.com', '$2y$10$1OeO/BMPPPwhqW7czX270edVzaEa3uitmUKK7F73aiRXkLWYwFV1O', 'eee', 0, '2q1c45r17ckfga2a64kn3tmamj'),
(7, 'ccc@gmail.com', '$2y$10$wPcn/5CdWLT3wFo5Xc9kw.smQWy5s/4/7YCcNumLhsxsL57.ZJh2q', 'ccc', 0, '5mm1uc0hcnmr34srm6iah9h18f'),
(11, '123@gmail.com', '$2y$10$dEo7ud4GLrV/qbOlHydSi.ZjygEFmdl81fjVtbSUn1b958tycjD62', '123', 0, 'bobcvs7o9a4s22ttav9jkiqsn3'),
(12, '1234@gmail.com', '$2y$10$JHtJRysuJIbDfeF2C38wROzU2An9XOnt5aC8NnRtB5vUePj3/gmD2', '1234', 0, 'u3gfi9atgjphf6k44qnpm53unc');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anime_manga`
--
ALTER TABLE `anime_manga`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anime_manga`
--
ALTER TABLE `anime_manga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
