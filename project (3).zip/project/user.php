<?php require_once "controller/require_login.php" ?>

<?php require_once "controller/PageBuilder.php"; ?>

<?php PageBuilder::start("User"); ?>

<?php require_once "controller/user.php"; ?>
<?php require_once "view/user.php"; ?>

<?php PageBuilder::end(); ?>