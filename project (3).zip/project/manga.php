<?php require_once "controller/require_login.php" ?>
<?php require_once "controller/PageBuilder.php"; 

 PageBuilder::start("Home"); 

 require_once "controller/manga.php"; 
 require_once "view/manga.php"; 

 PageBuilder::end(); ?>